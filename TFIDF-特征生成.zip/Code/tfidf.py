import os
import numpy as np


def load_files():
    files = []
    for i in os.listdir("dataset"):
        for f in os.listdir("dataset/" + i):
            files.append("dataset/" + i + "/" + f)
    return files


file_names = load_files()
dataset = []
for i in file_names:
    with open(i, 'rb') as f:
        data = f.read()
        str_data = data.decode(encoding='UTF-8', errors='replace').lower()
        dataset.append(str_data.split())
print(dataset[0])
